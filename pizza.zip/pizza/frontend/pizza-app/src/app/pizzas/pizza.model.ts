export interface Pizza {
  id: string;
  title: string;
  content: string;
}
